<?php
declare(strict_types=1);
define('PUBLIC_ROOT', __DIR__);
require dirname(__DIR__).'/emotional-spending-private/app/bootstrap.php';
$config['base_url']=setting('base_url',$config['base_url']);
$path=rtrim(rawurldecode(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/'),'/')?:'/';
if(str_starts_with($path,'/admin')) { require ROOT.'/app/admin.php'; exit; }
if($path==='/theme.css') {
    header('Content-Type: text/css; charset=utf-8');header('Cache-Control: public, max-age=300');
    $colors=['primary_color'=>'--sage','accent_color'=>'--accent','background_color'=>'--ivory','text_color'=>'--ink'];echo ':root {';
    foreach($colors as $key=>$css)if(preg_match('/^#[a-f0-9]{6}$/i',setting($key)))echo $css.':'.setting($key).';';
    echo '--logo-width:'.max(100,min(240,(int)setting('logo_size','190'))).'px;';
    if(setting('heading_font')==='classic')echo '--heading:Georgia,serif;';
    if(setting('body_font')==='system')echo '--body:Arial,sans-serif;';
    if(setting('button_style')==='rounded')echo '--button-radius:30px;';echo '}';
    if(setting('header_layout')==='compact')echo '.header-inner{height:76px}';exit;
}
if($path==='/checkout') {
    if(ready()) { header('Referrer-Policy: no-referrer');redirect(setting('checkout_url')); }
    flash('The workbook isn’t available for purchase yet. We’ll open checkout after the content and both editions are verified.','info');redirect('/our-workbook#availability');
}
if($path==='/robots.txt') { header('Content-Type: text/plain');echo "User-agent: *\nDisallow: /admin\nDisallow: /checkout\nSitemap: ".rtrim($config['base_url'],'/')."/sitemap.xml\n";exit; }
if($path==='/sitemap.xml') {
    header('Content-Type: application/xml; charset=utf-8');echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    $routes=['/blog'];foreach(query('SELECT slug FROM pages WHERE published=1')->fetchAll() as $row)$routes[]=$row['slug']==='home'?'/':'/'.$row['slug'];
    foreach(query("SELECT slug FROM posts WHERE status='published' AND published_at<=?",[gmdate('Y-m-d')])->fetchAll() as $row)$routes[]='/blog/'.$row['slug'];
    foreach($routes as $route)echo '<url><loc>'.e(rtrim($config['base_url'],'/').$route).'</loc></url>';echo '</urlset>';exit;
}
if(setting('site_status')==='maintenance'&&!is_admin()) { http_response_code(503);header('Retry-After: 3600');$title='A little pause';$description='We’re preparing our next chapter.';$noindex=true;include ROOT.'/templates/header.php';echo '<section class="error-page"><p class="eyebrow">OUR NEXT CHAPTER IS ON ITS WAY</p><h1>A little pause.</h1><p>We’re making a few thoughtful updates. Please visit again soon.</p><a class="text-link" href="mailto:'.e(setting('contact_email')).'">Get in touch ↗</a></section>';include ROOT.'/templates/footer.php';exit; }
if($path==='/blog') {
    $title='The journal';$description='Thoughtful reads on emotional spending, everyday awareness, and making space for more intentional choices.';
    $category=trim((string)($_GET['category']??''));
    $cards=query("SELECT * FROM posts WHERE status='published' AND published_at<=?".($category?' AND category=?':'').' ORDER BY published_at DESC,id DESC',$category?[gmdate('Y-m-d'),$category]:[gmdate('Y-m-d')])->fetchAll();
    include ROOT.'/templates/header.php';
    echo '<section class="blog-header container"><p class="eyebrow">A LITTLE MORE PERSPECTIVE</p><h1>The emotional spending journal.</h1><p>Thoughtful reads on the feelings behind our purchases, and the small choices that make room for change.</p></section><div class="container category-filters"><a class="'.(!$category?'active':'').'" href="/blog">All stories</a>';
    foreach(query('SELECT name FROM categories ORDER BY name')->fetchAll() as $cat)echo '<a class="'.($category===$cat['name']?'active':'').'" href="/blog?category='.rawurlencode($cat['name']).'">'.e($cat['name']).'</a>';
    echo '</div><section class="container blog-all"><div class="journal-grid">';foreach($cards as $card)include ROOT.'/templates/post-card.php';echo '</div>';if(!$cards)echo '<div class="empty-state"><h2>A new story is taking shape.</h2><p>There are no published articles in this category yet.</p><a class="text-link" href="/blog">Read all stories ↗</a></div>';echo '</section>';include ROOT.'/templates/footer.php';exit;
}
if(preg_match('~^/blog/([a-z0-9-]+)$~',$path,$match)) {
    $post=query("SELECT * FROM posts WHERE slug=? AND status='published' AND published_at<=?",[$match[1],gmdate('Y-m-d')])->fetch();
    if($post) { require ROOT.'/templates/article.php';exit; }
}
$config['base_url']=setting('base_url',$config['base_url']);
$slug=$path==='/'?'home':ltrim($path,'/');$page=query('SELECT * FROM pages WHERE slug=? AND published=1',[$slug])->fetch();
if(!$page) { http_response_code(404);$title='Page not found';$description='Find your way back to Emotional Spending.';$noindex=true;include ROOT.'/templates/header.php';echo '<section class="error-page"><p class="eyebrow">A SMALL DETOUR</p><h1>Let’s find your way back.</h1><p>That page isn’t here. There’s still plenty to explore.</p><a class="button" href="/">Back to home ↗</a></section>';include ROOT.'/templates/footer.php';exit; }
$errors=[];
if($slug==='contact-us'&&$_SERVER['REQUEST_METHOD']==='POST') {
    try { verify_csrf(); } catch(RuntimeException $ex) { $errors[]=$ex->getMessage(); }
    $name=trim((string)($_POST['name']??''));$email=trim((string)($_POST['email']??''));$subject=trim((string)($_POST['subject']??''));$body=trim((string)($_POST['message']??''));
    if($name===''||mb_strlen($name)>190)$errors[]='Please enter a name of up to 190 characters.';
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>254)$errors[]='Please enter a valid email address.';
    if($subject===''||mb_strlen($subject)>255)$errors[]='Please enter a subject of up to 255 characters.';
    if(mb_strlen($body)<10||mb_strlen($body)>10000)$errors[]='Please write a message between 10 and 10,000 characters.';
    if(empty($_POST['privacy']))$errors[]='Please acknowledge the Privacy Policy.';
    if(!empty($_POST['website']))$errors[]='We could not accept that submission.';
    if(!$errors&&rate_limited('contact',5,3600))$errors[]='You’ve sent several messages recently. Please try again later or email us directly.';
    if(!$errors){$message=compact('name','email','subject','body');query('INSERT INTO messages (name,email,subject,body,created_at) VALUES (?,?,?,?,?)',[$name,$email,$subject,$body,gmdate('c')]);$id=(int)db()->lastInsertId();$status=notification($id,$message);query('UPDATE messages SET notification_status=? WHERE id=?',[$status,$id]);flash('Thank you—your message has been received. We’ll reply to the email address you provided.');redirect('/contact-us');}
    if(http_response_code()!==419)http_response_code(422);
}
$title=$page['title'];$description=$page['description'];$bodyClass=$slug;
include ROOT.'/templates/header.php';
foreach(section_data($slug) as $index=>$section) { include ROOT.'/templates/section.php';if($slug==='our-workbook'&&$index===0)echo '<aside class="product-summary-bar"><span>'.e(setting('product_name')).'</span><span>'.e(price()).' <small>USD · one-time</small></span>'.purchase('','button').'</aside>'; }
if($slug==='contact-us')include ROOT.'/templates/contact.php';
include ROOT.'/templates/footer.php';
