<?php
declare(strict_types=1);
function input(string $key,int $max=10000): string {
    $value=$_POST[$key]??'';if(!is_string($value)||mb_strlen($value)>$max)throw new RuntimeException('A form value is invalid or too long.');return $value;
}
function admin_action(): void {
    $action=input('action',60);
    if($action==='logout'){audit('Administrator signed out');$_SESSION=[];session_regenerate_id(true);redirect('/admin/login');}
    if($action==='save_page') {
        $slug=input('slug',120);if(!query('SELECT slug FROM pages WHERE slug=?',[$slug])->fetch())throw new RuntimeException('Page not found.');
        $title=trim(input('title',255));if(!$title)throw new RuntimeException('The page title is required.');
        $rows=$_POST['sections']??[];$order=$_POST['section_order']??[];
        if(!is_array($rows)||!is_array($order)||count($order)>60)throw new RuntimeException('Invalid section data.');
        db()->beginTransaction();query('UPDATE pages SET title=?,description=?,published=? WHERE slug=?',[$title,input('description',1000),isset($_POST['published'])?1:0,$slug]);
        foreach($order as $position=>$id){$id=(int)$id;$old=query('SELECT * FROM sections WHERE id=? AND page_slug=?',[$id,$slug])->fetch();if(!$old)continue;$row=$rows[$id]??[];
            if(!is_array($row))throw new RuntimeException('Invalid section.');
            if(!empty($row['remove'])){query('DELETE FROM sections WHERE id=?',[$id]);continue;}
            $content=json_decode($old['content'],true)?:[];
            foreach(['eyebrow','title','subtitle','body','button_label','button_url','secondary_label','secondary_url','image'] as $key){if(isset($row[$key])){if(!is_string($row[$key])||mb_strlen($row[$key])>30000)throw new RuntimeException('Section text is too long.');$content[$key]=$row[$key];}}
            foreach(['button_url','secondary_url'] as $url)if(!empty($content[$url])&&!safe_url($content[$url]))throw new RuntimeException('Use a relative link or a valid HTTPS/HTTP link for buttons.');
            if(isset($row['_items_present'])) {$row['items']=$row['items']??[];if(!is_array($row['items'])||count($row['items'])>50)throw new RuntimeException('Too many content items.');$content['items']=[];foreach($row['items'] as $item){if(!is_array($item))continue;$itemTitle=trim((string)($item['title']??''));$itemText=trim((string)($item['text']??''));if(mb_strlen($itemTitle)>500||mb_strlen($itemText)>5000)throw new RuntimeException('A content item is too long.');if($itemTitle!==''||$itemText!=='')$content['items'][]=['title'=>$itemTitle,'text'=>$itemText];}}
            query('UPDATE sections SET content=?,position=?,visible=? WHERE id=? AND page_slug=?',[json_encode($content,JSON_THROW_ON_ERROR),$position,isset($row['visible'])?1:0,$id,$slug]);
        }
        db()->commit();audit('Updated page: '.$slug);flash('Page content and section order saved.');return;
    }
    if($action==='add_section') {
        $slug=input('slug',120);$kind=input('kind',40);
        if(!query('SELECT slug FROM pages WHERE slug=?',[$slug])->fetch()||!in_array($kind,['text','features','connection','journey','research','reflection','editions','journal','faq','cta','chapters','pause','preview'],true))throw new RuntimeException('Choose a valid page and section type.');
        query('INSERT INTO sections (page_slug,kind,content,position,visible) VALUES (?,?,?,?,0)',[$slug,$kind,json_encode(['eyebrow'=>'','title'=>'New section','body'=>'','items'=>[]]),999]);audit('Added section to '.$slug);flash('Section added, hidden until you publish it.');return;
    }
    if($action==='save_product') {
        $amount=input('price',20);if(!preg_match('/^\d{1,4}(\.\d{1,2})?$/',$amount)||(float)$amount<0.01)throw new RuntimeException('Enter a price between 0.01 and 9999.99.');
        $url=trim(input('checkout_url',2000));if($url!==''&&!whop_url($url))throw new RuntimeException('Use an official HTTPS whop.com/checkout/… product checkout link. General Whop and network URLs are not accepted.');
        $currency=input('currency',3);if(!in_array($currency,['USD','EUR','GBP','CAD','AUD'],true))throw new RuntimeException('Choose a supported currency.');
        $availability=input('availability',30);if(!in_array($availability,['preparing','available','unavailable'],true))throw new RuntimeException('Invalid product availability.');
        $pageCount=(int)input('page_count',4);if($pageCount<1||$pageCount>2000)throw new RuntimeException('Enter a page count between 1 and 2000.');
        if($availability==='available'&&(!$url||!isset($_POST['content_verified'],$_POST['printable_ready'],$_POST['fillable_ready'])))throw new RuntimeException('Verify the original content, printable edition, fillable edition, and checkout delivery before making the product available.');
        foreach(['product_name','subtitle','product_description','cta_text','printable_description','fillable_description','whop_plan'] as $key)set_setting($key,trim(input($key,5000)));
        foreach(['content_verified','printable_ready','fillable_ready'] as $key)set_setting($key,isset($_POST[$key])?'1':'0');
        set_setting('cover',image_url(input('cover',255)));set_setting('price',number_format((float)$amount,2,'.',''));set_setting('currency',$currency);set_setting('availability',$availability);set_setting('checkout_url',$url);set_setting('page_count',(string)$pageCount);
        $features=array_values(array_filter(array_map('trim',explode("\n",input('features',5000)))));set_setting('features',array_slice($features,0,30));
        audit('Updated product and checkout configuration');flash('Product saved. Website price changes do not change the price in Whop.');return;
    }
    if($action==='save_post') {
        $id=(int)input('id',20);$slug=trim(input('slug',190));$title=trim(input('title',255));$category=trim(input('category',120));$status=input('status',20);$date=input('published_at',30);
        if(!$title||!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/',$slug))throw new RuntimeException('An article needs a title and a lowercase hyphenated slug.');
        if(!in_array($status,['draft','published'],true))throw new RuntimeException('Invalid article status.');
        $parsed=DateTimeImmutable::createFromFormat('!Y-m-d',$date);if(!$parsed||$parsed->format('Y-m-d')!==$date)throw new RuntimeException('Enter a valid publication date.');
        if(query('SELECT id FROM posts WHERE slug=? AND id<>?',[$slug,$id])->fetch())throw new RuntimeException('That article slug is already in use.');
        if($category&&!query('SELECT name FROM categories WHERE name=?',[$category])->fetch())query('INSERT INTO categories (name) VALUES (?)',[$category]);
        $values=[$slug,$title,input('excerpt',2000),input('body',100000),$category,input('image',255)?image_url(input('image',255),''):'',$status,$date,input('author',190),input('seo_title',255),input('seo_description',1000),gmdate('c')];
        if($id){if(!query('SELECT id FROM posts WHERE id=?',[$id])->fetch())throw new RuntimeException('Article not found.');query('UPDATE posts SET slug=?,title=?,excerpt=?,body=?,category=?,image=?,status=?,published_at=?,author=?,seo_title=?,seo_description=?,updated_at=? WHERE id=?',[...$values,$id]);}
        else{query('INSERT INTO posts (slug,title,excerpt,body,category,image,status,published_at,author,seo_title,seo_description,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',$values);$id=(int)db()->lastInsertId();}
        audit('Saved article: '.$title);flash('Article saved. Future-dated articles appear on their publication date.');redirect('/admin/posts?id='.$id);
    }
    if($action==='delete_post') {query('DELETE FROM posts WHERE id=?',[(int)input('id',20)]);audit('Deleted article');flash('Article deleted.');redirect('/admin/posts');}
    if($action==='save_category'){$name=trim(input('name',120));if(!$name)throw new RuntimeException('Enter a category name.');if(!query('SELECT name FROM categories WHERE name=?',[$name])->fetch())query('INSERT INTO categories (name) VALUES (?)',[$name]);flash('Category added.');return;}
    if($action==='delete_category'){$name=input('name',120);query('UPDATE posts SET category=? WHERE category=?',['Uncategorized',$name]);query('DELETE FROM categories WHERE name=?',[$name]);flash('Category removed; associated posts are now Uncategorized.');return;}
    if($action==='upload') {
        $file=$_FILES['image']??null;
        if(!$file||!is_array($file)||$file['error']!==UPLOAD_ERR_OK||$file['size']>5*1024*1024||!is_uploaded_file($file['tmp_name']))throw new RuntimeException('Choose a JPEG, PNG, or WebP image under 5 MB.');
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;$size=@getimagesize($file['tmp_name']);
        if(!$ext||!$size||$size[0]>12000||$size[1]>12000||$size[0]*$size[1]>40000000)throw new RuntimeException('This is not a supported image, or its dimensions are too large. SVG, executable files, and PDFs are not accepted.');
        $alt=trim(input('alt_text',500));if(!$alt)throw new RuntimeException('Add a meaningful alternative description.');
        $filename=bin2hex(random_bytes(18)).'.'.$ext;if(!move_uploaded_file($file['tmp_name'],PUBLIC_ROOT.'/uploads/'.$filename))throw new RuntimeException('The upload folder is not writable.');chmod(PUBLIC_ROOT.'/uploads/'.$filename,0644);
        query('INSERT INTO media (filename,original_name,alt_text,width,height,created_at) VALUES (?,?,?,?,?,?)',[$filename,mb_substr(basename($file['name']),0,255),$alt,$size[0],$size[1],gmdate('c')]);audit('Uploaded media');flash('Image uploaded. It is now available in image selectors.');return;
    }
    if($action==='save_media'){query('UPDATE media SET alt_text=? WHERE id=?',[trim(input('alt_text',500)),(int)input('id',20)]);flash('Image description saved.');return;}
    if($action==='delete_media') {
        $id=(int)input('id',20);$media=query('SELECT * FROM media WHERE id=?',[$id])->fetch();if(!$media)throw new RuntimeException('Image not found.');
        if(query('SELECT id FROM previews WHERE media_id=?',[$id])->fetch()||query('SELECT id FROM posts WHERE image=?',['/uploads/'.$media['filename']])->fetch()||query('SELECT key_name FROM settings WHERE value LIKE ?',['%'.$media['filename'].'%'])->fetch()||query('SELECT id FROM sections WHERE content LIKE ?',['%'.$media['filename'].'%'])->fetch())throw new RuntimeException('This image is in use. Remove its references before deleting it.');
        unlink(PUBLIC_ROOT.'/uploads/'.$media['filename']);query('DELETE FROM media WHERE id=?',[$id]);audit('Deleted unused media');flash('Image deleted.');return;
    }
    if($action==='add_preview') {$media=(int)input('media_id',20);$caption=trim(input('caption',500));if(!$caption||!query('SELECT id FROM media WHERE id=?',[$media])->fetch())throw new RuntimeException('Choose a genuine uploaded workbook preview and add a caption.');query('INSERT INTO previews (media_id,caption,position,visible) VALUES (?,?,?,1)',[$media,$caption,(int)input('position',10)]);audit('Added workbook preview');flash('Preview added. Only publish authentic selected pages, never the complete paid PDF.');return;}
    if($action==='save_previews') {foreach(($_POST['previews']??[]) as $id=>$row){if(!empty($row['remove']))query('DELETE FROM previews WHERE id=?',[(int)$id]);else query('UPDATE previews SET caption=?,position=?,visible=? WHERE id=?',[mb_substr((string)($row['caption']??''),0,500),(int)($row['position']??0),isset($row['visible'])?1:0,(int)$id]);}audit('Updated workbook previews');flash('Previews saved.');return;}
    if($action==='save_faqs') {foreach(($_POST['faqs']??[]) as $id=>$row){if(!empty($row['remove']))query('DELETE FROM faqs WHERE id=?',[(int)$id]);else query('UPDATE faqs SET question=?,answer=?,position=?,visible=? WHERE id=?',[mb_substr((string)($row['question']??''),0,500),mb_substr((string)($row['answer']??''),0,10000),(int)($row['position']??0),isset($row['visible'])?1:0,(int)$id]);}$question=trim(input('new_question',500));if($question)query('INSERT INTO faqs (question,answer,position,visible) VALUES (?,?,?,1)',[$question,input('new_answer',10000),999]);audit('Updated FAQs');flash('Questions and answers saved.');return;}
    if($action==='save_navigation') {
        $links=[];foreach(($_POST['links']??[]) as $row){$label=trim((string)($row['label']??''));$url=trim((string)($row['url']??''));if(!$label||!empty($row['remove']))continue;if(strlen($label)>100||!safe_url($url))throw new RuntimeException('Every navigation link needs a short label and a valid destination.');$links[]=['label'=>$label,'url'=>$url,'visible'=>isset($row['visible'])];}
        set_setting('navigation',array_slice($links,0,20));$legal=[];foreach(($_POST['legal_links']??[]) as $row){if(empty($row['label'])||!empty($row['remove']))continue;$url=safe_url((string)($row['url']??''));if(!$url)throw new RuntimeException('Invalid legal link.');$legal[]=['label'=>mb_substr((string)$row['label'],0,100),'url'=>$url,'visible'=>isset($row['visible'])];}set_setting('legal_navigation',array_slice($legal,0,10));set_setting('footer_description',input('footer_description',2000));$socials=[];foreach(($_POST['socials']??[]) as $row){if(empty($row['label'])||empty($row['url'])||!empty($row['remove']))continue;if(!safe_url((string)$row['url']))throw new RuntimeException('Invalid social URL.');$socials[]=['label'=>mb_substr((string)$row['label'],0,100),'url'=>(string)$row['url']];}set_setting('socials',array_slice($socials,0,10));audit('Updated navigation and footer');flash('Navigation and footer saved. Rows appear in their displayed order.');return;
    }
    if($action==='save_theme') {
        $colors=[];foreach(['primary_color','accent_color','background_color','text_color'] as $key){$color=input($key,7);if(!preg_match('/^#[a-f0-9]{6}$/i',$color))throw new RuntimeException('Use a six-digit hex color.');$colors[$key]=$color;}
        if(contrast($colors['text_color'],$colors['background_color'])<4.5||contrast('#ffffff',$colors['primary_color'])<4.5)throw new RuntimeException('Keep text/background and white button/primary contrast at least 4.5:1 for readability.');
        foreach($colors as $key=>$color)set_setting($key,$color);
        foreach(['heading_font'=>['editorial','classic'],'body_font'=>['sans','system'],'button_style'=>['square','rounded'],'header_layout'=>['standard','compact']] as $key=>$options){$value=input($key,30);if(!in_array($value,$options,true))throw new RuntimeException('Invalid theme option.');set_setting($key,$value);}
        set_setting('logo_size',(string)max(100,min(240,(int)input('logo_size',4))));foreach(['logo','og_image'] as $key)set_setting($key,input($key,255)?image_url(input($key,255),''):'');audit('Updated visual theme');flash('Theme saved.');return;
    }
    if($action==='save_settings') {
        $email=trim(input('contact_email',254));if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Enter a valid contact email.');
        $url=trim(input('base_url',1000));if(!filter_var($url,FILTER_VALIDATE_URL)||parse_url($url,PHP_URL_SCHEME)!=='https'||parse_url($url,PHP_URL_USER)||!in_array(parse_url($url,PHP_URL_PATH),[null,'','/'],true)||parse_url($url,PHP_URL_QUERY)||parse_url($url,PHP_URL_FRAGMENT))throw new RuntimeException('The public domain must be an HTTPS root URL with no credentials, query, or fragment.');
        $host=trim(input('smtp_host',255));$port=(int)input('smtp_port',5);$security=input('smtp_security',10);$from=trim(input('smtp_from',254));
        if($host!==''&&(!preg_match('/^[a-zA-Z0-9.-]+$/',$host)||!in_array($port,[465,587],true)||!filter_var($from,FILTER_VALIDATE_EMAIL)))throw new RuntimeException('SMTP requires a valid hostname, port 465 or 587, and sender email.');
        if(!in_array($security,['tls','ssl'],true))throw new RuntimeException('SMTP must use STARTTLS or implicit TLS.');
        foreach(['brand','tagline','business_name','business_address','jurisdiction','smtp_user'] as $key)set_setting($key,trim(input($key,2000)));
        set_setting('contact_email',$email);set_setting('base_url',rtrim($url,'/'));set_setting('smtp_host',$host);set_setting('smtp_port',(string)$port);set_setting('smtp_security',$security);set_setting('smtp_from',$from);
        if(input('smtp_password',5000)!=='')set_setting('smtp_password',encrypt_secret(input('smtp_password',5000)));
        if(isset($_POST['clear_smtp_password']))set_setting('smtp_password','');
        set_setting('site_status',input('site_status',20)==='maintenance'?'maintenance':'public');audit('Updated site, legal, and SMTP settings');flash('Settings saved. Analytics and nonessential tracking remain disabled.');return;
    }
    if($action==='test_smtp'){if(notification(0,['name'=>'Website administrator','email'=>setting('contact_email'),'subject'=>'SMTP configuration test','body'=>'Your Emotional Spending website successfully connected to its configured SMTP provider.'])!=='sent')throw new RuntimeException('Test notification failed or SMTP is not configured. Verify your settings and server error log.');flash('SMTP test sent to the configured contact email.');return;}
    if($action==='message_status') {$status=input('status',20);if(!in_array($status,['unread','read','resolved'],true))throw new RuntimeException('Invalid message status.');query('UPDATE messages SET status=? WHERE id=?',[$status,(int)input('id',20)]);flash('Message status updated.');return;}
    if($action==='delete_message'){query('DELETE FROM messages WHERE id=?',[(int)input('id',20)]);audit('Deleted contact message');flash('Message deleted.');return;}
    if($action==='change_password') {$admin=query('SELECT * FROM admins WHERE id=?',[$_SESSION['admin_id']])->fetch();if(!password_verify(input('current_password',1024),$admin['password_hash']))throw new RuntimeException('Your current password is not correct.');$new=input('new_password',1024);if(strlen($new)<12||$new!==input('confirm_password',1024))throw new RuntimeException('Use at least 12 characters and enter the same new password twice.');query('UPDATE admins SET password_hash=? WHERE id=?',[password_hash($new,PASSWORD_DEFAULT),$admin['id']]);session_regenerate_id(true);audit('Changed administrator password');flash('Password changed.');return;}
    throw new RuntimeException('That action is not available.');
}
function contrast(string $a,string $b): float {
    $l=function($hex){$v=sscanf($hex,'#%02x%02x%02x');$v=array_map(fn($c)=>($c/255<=0.04045)?($c/255/12.92):pow(($c/255+0.055)/1.055,2.4),$v);return $v[0]*.2126+$v[1]*.7152+$v[2]*.0722;};$x=$l($a);$y=$l($b);return (max($x,$y)+.05)/(min($x,$y)+.05);
}
