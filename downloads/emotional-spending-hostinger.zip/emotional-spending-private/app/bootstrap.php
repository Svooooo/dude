<?php
declare(strict_types=1);
define('ROOT', dirname(__DIR__));
if (!defined('PUBLIC_ROOT')) define('PUBLIC_ROOT', ROOT . '/public');
$local = is_file(ROOT . '/config.local.php') ? require ROOT . '/config.local.php' : [];
$config = array_merge([
    'dsn' => getenv('ES_DB_DSN') ?: 'sqlite:' . ROOT . '/storage/site.sqlite',
    'db_user' => getenv('ES_DB_USER') ?: '',
    'db_password' => getenv('ES_DB_PASSWORD') ?: '',
    'base_url' => getenv('ES_BASE_URL') ?: 'https://www.emotionalspending.com',
    'setup_token' => getenv('ES_SETUP_TOKEN') ?: '', 'debug' => false,
], $local);
date_default_timezone_set('UTC');
ini_set('display_errors', '0');
ini_set('log_errors', '1');
if (PHP_SAPI !== 'cli') {
    $cspNonce = base64_encode(random_bytes(18));
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: DENY');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; font-src 'self'; script-src 'self' 'nonce-$cspNonce'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') header('Strict-Transport-Security: max-age=31536000');
    ini_set('session.use_strict_mode', '1');
    $sessionDirectory = ROOT . '/storage/sessions';
    if (!is_dir($sessionDirectory)) mkdir($sessionDirectory, 0700, true);
    session_save_path($sessionDirectory);
    ini_set('session.gc_probability', '1');
    ini_set('session.gc_divisor', '100');
    ini_set('session.gc_maxlifetime', '1800');
    session_name('emotional_spending');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','httponly'=>true,'samesite'=>'Lax']);
    session_start();
    if (isset($_SESSION['admin_id']) && time() - ($_SESSION['last_active'] ?? 0) > 1800) {
        $_SESSION = []; session_regenerate_id(true);
    }
    if (isset($_SESSION['admin_id'])) $_SESSION['last_active'] = time();
}
require ROOT . '/app/functions.php';
require ROOT . '/app/seed.php';
set_exception_handler(function (Throwable $e): void {
    error_log('[Emotional Spending] ' . $e->getMessage());
    http_response_code(500);
    if (PHP_SAPI === 'cli') { fwrite(STDERR, "Operation failed. See PHP error log.\n"); exit(1); }
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>We’ll be right back</title><link rel="stylesheet" href="/assets/site.css"><main class="error-page"><p class="eyebrow">EMOTIONAL SPENDING</p><h1>A little pause.</h1><p>We couldn’t complete that request. Please try again shortly.</p><a class="button" href="/">Back to home</a></main></html>';
});
