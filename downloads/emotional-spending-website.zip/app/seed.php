<?php
declare(strict_types=1);
function seed(PDO $db): void {
    $settings = [
        'brand'=>'Emotional Spending','tagline'=>'A little awareness. A different relationship with spending.',
        'contact_email'=>'contact@emotionalspending.com','product_name'=>"It’s Not About the Money",'subtitle'=>"It’s About Why You Spend It.",
        'price'=>'27.99','currency'=>'USD','page_count'=>'48','product_description'=>'A thoughtful, practical workbook for understanding the feelings behind your purchases—and finding a little more space to choose.',
        'cover'=>'/assets/book-cover.svg','logo'=>'','og_image'=>'/assets/share.svg','checkout_url'=>'','whop_plan'=>'',
        'availability'=>'preparing','content_verified'=>'0','printable_ready'=>'0','fillable_ready'=>'0','cta_text'=>'Get my workbook',
        'printable_description'=>'Space to slow down, put pen to paper, and reflect at your own pace.',
        'fillable_description'=>'A digital edition is planned. Availability will be confirmed after its fillable fields and saving behavior have been tested.',
        'primary_color'=>'#586747','accent_color'=>'#7e8b68','background_color'=>'#faf9f5','text_color'=>'#282b27',
        'heading_font'=>'editorial','body_font'=>'sans','button_style'=>'square','logo_size'=>'190','header_layout'=>'standard',
        'footer_description'=>'Thoughtful tools for a more intentional relationship with spending. Understanding first. Change at your pace.',
        'business_name'=>'','business_address'=>'','jurisdiction'=>'','site_status'=>'public',
        'smtp_host'=>'','smtp_user'=>'','smtp_password'=>'','smtp_port'=>'587','smtp_security'=>'tls','smtp_from'=>'',
        'legal_navigation'=>json_encode([['label'=>'Terms of use','url'=>'/terms-of-use','visible'=>true],['label'=>'Privacy policy','url'=>'/privacy-policy','visible'=>true]]),'socials'=>json_encode([]),'navigation'=>json_encode([
            ['label'=>'Home','url'=>'/','visible'=>true],['label'=>'About us','url'=>'/about-us','visible'=>true],
            ['label'=>'Our workbook','url'=>'/our-workbook','visible'=>true],['label'=>'Journal','url'=>'/blog','visible'=>true],['label'=>'Contact us','url'=>'/contact-us','visible'=>true]
        ]),
        'features'=>json_encode(['Eight thoughtful chapters','Practical worksheets & reflection prompts','The PAUSE before purchase framework','A guided 30-day experience','A 90-day continuation roadmap','Behavioral science & consumer psychology']),
    ];
    $s=$db->prepare('INSERT INTO settings (key_name,value) VALUES (?,?)');foreach($settings as $k=>$v)$s->execute([$k,$v]);
    $pages=[
        'home'=>['A more thoughtful way to spend','Understand the feelings behind your purchases. Discover a research-informed emotional spending workbook, practical reflection tools, and a guided 30-day experience.'],
        'about-us'=>['Awareness before judgment','Our mission is to make ideas about spending behavior more accessible, practical, and useful in everyday life.'],
        'our-workbook'=>['A little space between the urge and the purchase','Explore It’s Not About the Money, a practical emotional spending workbook with guided reflection, a 30-day program, and tools for continued learning.'],
        'contact-us'=>['Let’s talk','Questions about the workbook or accessing your digital purchase? Contact Emotional Spending.'],
        'terms-of-use'=>['Terms of use','Read our terms for educational content, digital purchases, personal-use licensing, delivery, and your consumer rights.'],
        'privacy-policy'=>['Privacy policy','Learn how Emotional Spending handles contact messages, essential cookies, technical information, and external Whop payments.'],
    ];
    $p=$db->prepare('INSERT INTO pages (slug,title,description,published) VALUES (?,?,?,1)');foreach($pages as $slug=>$v)$p->execute([$slug,...$v]);
    $sections=[];
    $add=function(string $page,string $kind,array $content)use(&$sections){$normalize=function(&$value) { if(is_string($value))$value=str_replace('\\n',"\n",$value); };array_walk_recursive($content,$normalize);$sections[]=[$page,$kind,json_encode($content,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),count($sections),1];};
    $hero=['eyebrow'=>'A MORE INTENTIONAL WAY TO SPEND','title'=>"It’s not about\nthe money.",'subtitle'=>"It’s about why you spend it.",'body'=>'Sometimes, what we buy has more to do with how we feel. Make space to understand your patterns—and practice a more thoughtful way forward.','button_label'=>'Explore the workbook','button_url'=>'/our-workbook','secondary_label'=>'Discover the approach','secondary_url'=>'/#approach'];
    $add('home','hero',$hero);
    $add('home','connection',['eyebrow'=>'SOUND FAMILIAR?','title'=>"Sometimes, the purchase isn’t what you’re really looking for.",'body'=>'A difficult day. A quiet evening. A sale that feels too good to miss. Shopping can offer a moment of comfort—but that feeling doesn’t always last. You’re not alone, and you don’t need another reason to be hard on yourself.','items'=>[
        ['title'=>'“I’ve had a long day. I deserve this.”','text'=>'When a purchase feels like a little relief.'],['title'=>'“It’s on sale. I’d be losing money.”','text'=>'When urgency makes the decision for you.'],['title'=>'“I’ll feel better once it arrives.”','text'=>'When the anticipation is what you’re really buying.']]]);
    $add('home','features',['eyebrow'=>'A DIFFERENT STARTING POINT','title'=>"Less judgment.\nMore understanding.",'body'=>'A budget can show you where your money went. This workbook invites you to explore what happened before you spent it.','items'=>[
        ['title'=>'Grounded in research','text'=>'Accessible ideas from behavioral science and consumer psychology. No quick fixes or big promises.'],
        ['title'=>'Made for real life','text'=>'Guided reflection, practical worksheets, and small steps that fit into an ordinary day.'],
        ['title'=>'A little structure','text'=>'A four-week journey to notice patterns, understand needs, and try different responses.'],
        ['title'=>'Room to keep growing','text'=>'Reflection tools and a 90-day roadmap to support learning beyond the first month.']]]);
    $add('home','reflection',['eyebrow'=>'A MOMENT TO CHECK IN','title'=>'Before you add to cart, add a little curiosity.','body'=>'Try a simple reflection. There’s no right answer—just a little more awareness.','items'=>[
        ['title'=>'What am I feeling?','text'=>'Stress, boredom, excitement, loneliness… Naming the feeling can help you notice what is happening.'],['title'=>'What do I actually need?','text'=>'Could it be rest, connection, comfort, or a change of scene? A purchase is one possible response, not the only one.'],['title'=>'What else could I try?','text'=>'Give yourself a little time. Take a walk, message someone, or revisit the decision tomorrow.']]]);
    $journey=['eyebrow'=>'ONE DAY AT A TIME','title'=>"30 days. A little more\nunderstanding, every week.",'body'=>'Not a spending ban. Not a promise of perfection. A guided space to get curious about your habits and practice what works for you.','items'=>[
        ['title'=>'Awareness','text'=>'Notice your spending patterns and the feelings that come with them.'],['title'=>'Understanding','text'=>'Explore your triggers, automatic thoughts, and the needs beneath the urge.'],['title'=>'New responses','text'=>'Try a thoughtful pause, purchase delays, and alternatives that feel right for you.'],['title'=>'Lasting routines','text'=>'Create realistic boundaries and a flexible plan you can keep returning to.']]];
    $add('home','journey',$journey);
    $research=['eyebrow'=>'BUILT ON RESEARCH. MADE FOR EVERYDAY LIFE.','title'=>'Good questions begin with understanding behavior.','body'=>'Emotions, buying impulses, and habits all play a part in how we spend. The workbook’s approach brings these ideas into everyday reflection—without turning your finances into a test of willpower.','items'=>[
        ['title'=>'Consumer psychology','text'=>'Explore the feelings, expectations, and situations that shape buying decisions.'],['title'=>'Emotion regulation','text'=>'Notice emotional needs and consider responses beyond an automatic purchase.'],['title'=>'Behavior & habit formation','text'=>'Experiment with cues, planning, and routines that support more deliberate choices.']]];
    $add('home','research',$research);
    $add('home','editions',['eyebrow'=>'YOUR SPACE TO REFLECT','title'=>'On paper. On screen.\nAt your own pace.','body'=>'Two ways of working through the same ideas. Choose the format that fits your everyday life.']);
    $add('home','journal',['eyebrow'=>'THE EMOTIONAL SPENDING JOURNAL','title'=>'A little perspective,\nwhenever you need it.','body'=>'Thoughtful reads on spending, emotions, and making space for different choices.']);
    $add('home','faq',['eyebrow'=>'A FEW THINGS YOU MIGHT BE WONDERING','title'=>'Good questions.\nThoughtful answers.','body'=>'A little clarity before you decide.']);
    $cta=['eyebrow'=>'A MORE THOUGHTFUL WAY FORWARD','title'=>"You don’t need to be\na perfect spender.",'body'=>'Start with a little curiosity. Understand your patterns. Practice choices that feel more intentional.','button_label'=>'Explore the workbook','button_url'=>'/our-workbook'];
    $add('home','cta',$cta);
    $add('about-us','text',['eyebrow'=>'WHY WE’RE HERE','title'=>'A better understanding of spending starts with curiosity.','body'=>"Emotional Spending is an educational resource about the relationship between our emotions, habits, and financial decisions. We believe a more thoughtful relationship with money begins with understanding ourselves.\n\nOur mission is to make research-informed ideas about spending behavior more accessible, practical, and useful in everyday life. We bring behavioral understanding together with reflection tools you can use at your own pace.\n\nWe don’t believe in becoming a perfect spender. We believe in noticing patterns, making room for choice, and respecting the very real circumstances that shape your financial life."]);
    $add('about-us','features',['eyebrow'=>'OUR POINT OF VIEW','title'=>'Understanding first.\nChange at your pace.','body'=>'A kinder approach can still be a practical one.','items'=>[['title'=>'Awareness before judgment','text'=>'Observe what happens with curiosity, rather than turning every decision into a verdict.'],['title'=>'Understanding before restriction','text'=>'Explore the need behind an urge before deciding how you want to respond.'],['title'=>'Practice over perfection','text'=>'Small experiments and flexible routines are more useful than empty motivation.'],['title'=>'Respect for real life','text'=>'Your circumstances matter. A workbook can support reflection; it cannot remove financial hardship.']]]);
    $add('about-us','cta',$cta);
    $productHero=$hero;$productHero['eyebrow']='THE EMOTIONAL SPENDING WORKBOOK';$productHero['title']='A little space between the urge and the purchase.';$productHero['subtitle']='Meet your next chapter.';$productHero['body']=$settings['product_description'];$productHero['secondary_label']='Explore the chapters';$productHero['secondary_url']='/our-workbook#chapters';
    $add('our-workbook','hero',$productHero);
    $add('our-workbook','chapters',['eyebrow'=>'EIGHT CHAPTERS. A THOUGHTFUL PROGRESSION.','title'=>'Get to know your patterns.\nThen practice a different response.','body'=>'The planned content follows a simple progression from awareness to continued practice.','items'=>[
        ['title'=>'Understanding emotional spending','text'=>'Explore the connection between feelings, purchases, and short-term relief.'],['title'=>'Identifying your emotional triggers','text'=>'Map the situations, feelings, and cues that tend to precede spending.'],['title'=>'What happens before you buy','text'=>'Look at automatic thoughts, expectations, and buying impulses.'],['title'=>'The stories you tell yourself about money','text'=>'Reflect on familiar beliefs and try more flexible perspectives.'],['title'=>'Learning to respond differently','text'=>'Create space with PAUSE, purchase delays, and alternative responses.'],['title'=>'Creating a healthier spending environment','text'=>'Design practical boundaries and adjust everyday shopping cues.'],['title'=>'Your 30-day emotional spending reset','text'=>'Bring awareness and reflection into a manageable four-week practice.'],['title'=>'Breaking the cycle and maintaining change','text'=>'Review what helps and build a personal 90-day continuation plan.']]]);
    $add('our-workbook','pause',['eyebrow'=>'THE PAUSE FRAMEWORK','title'=>'A small pause can make room for a different choice.','body'=>'A self-reflection tool for the moment between wanting something and buying it.','items'=>[['title'=>'Pause','text'=>'Take a breath before acting.'],['title'=>'Acknowledge','text'=>'Name the emotion without judging it.'],['title'=>'Understand','text'=>'Ask what you need in this moment.'],['title'=>'Select','text'=>'Consider a response that suits that need.'],['title'=>'Evaluate','text'=>'Reflect on how the decision feels afterward.']]]);
    $add('our-workbook','journey',$journey);$add('our-workbook','preview',['eyebrow'=>'A LOOK INSIDE','title'=>'Take a closer look\nbefore you decide.','body'=>'Authentic workbook previews will be added before purchase becomes available.']);
    $add('our-workbook','editions',['eyebrow'=>'ONE WORKBOOK. YOUR WAY.','title'=>'Make it your own.','body'=>'A digital workbook, designed for reflection at your own pace. This is not a physical book.']);
    $add('our-workbook','research',$research);$add('our-workbook','faq',['eyebrow'=>'BEFORE YOU BEGIN','title'=>'A little more clarity.','body'=>'The practical details about the workbook, delivery, and support.']);$add('our-workbook','cta',$cta);
    $add('contact-us','text',['eyebrow'=>'WE’RE HERE TO HELP','title'=>'Let’s start a conversation.','body'=>'Have a question about the workbook, your digital purchase, or accessing your files? We’d be happy to help.']);
    $terms=<<<'TEXT'
## About this website

Emotional Spending provides educational information and digital reflection tools about spending habits. Our content is for adults and is not individualized financial, investment, legal, medical, or mental health advice. It does not diagnose or treat a condition, guarantee savings, or replace qualified support.

## Digital products and payment

The workbook is a digital PDF product, not a physical book. The product page and the live checkout describe the editions supplied and the price payable. Prices are in the displayed currency. Payments are completed through Whop under its applicable buyer terms. We do not collect or store payment-card details on this website. You must review the final price, applicable taxes, delivery details, and terms at checkout before paying.

## Access and personal use

After a successful payment, access is supplied through the delivery method described at checkout. Save your purchase confirmation and contact us if access is missing. A purchase grants a personal, nontransferable license to read and use the supplied files and print copies for your own use. You may not resell, share, publicly upload, redistribute, or commercially reproduce the files without permission. Intellectual property remains with its respective rights holders.

## Refunds and consumer rights

Because the workbook is a digital product and access is provided electronically, purchases are generally final once digital access has been supplied. Please review the description and available previews before purchasing. If you experience a delivery problem, receive an incorrect file, or believe the product is not as described, contact us so we can review and resolve the issue. Nothing in this policy limits your rights or remedies under applicable consumer protection law, or applicable Whop buyer protections. Where a statutory withdrawal right applies, any request for immediate supply and acknowledgement of a resulting loss of that right must be addressed by the actual checkout process.

## Responsible use and limitations

Use reflection exercises in a way that fits your circumstances. Pause if an exercise causes distress. If spending is causing serious harm or feels unmanageable, consider qualified financial or mental health support. The concepts described may draw on research; that does not mean this workbook or its program has been independently clinically validated. To the extent permitted by applicable law, we are not responsible for outcomes resulting from reliance on general educational content. Nothing excludes liability or rights that cannot lawfully be excluded.

## Questions and updates

Contact [contact@emotionalspending.com](mailto:contact@emotionalspending.com) about purchases, permissions, or these terms. We may update these terms; the terms supplied with your purchase and mandatory consumer rights remain applicable to that transaction.
TEXT;
    $privacy=<<<'TEXT'
## Information you choose to share

When you use our contact form, we collect your name, email address, subject, and message to respond and manage your request. Please do not include payment-card details, account passwords, or sensitive financial or health information. We process enquiries to take steps you request, respond to contractual matters, or pursue the legitimate interest of providing customer support, as applicable under your local law.

## Technical information and essential cookies

The website uses an essential session cookie for form protection and administrative authentication. Our server or hosting provider may keep technical access and error logs for reliability and security. Abuse controls retain a one-way hash of an IP address and request counters for a limited period. This implementation does not use advertising cookies, audience analytics, a newsletter service, or cross-site marketing trackers. There is no nonessential tracking to opt into.

## Payments and service providers

Payments and controlled digital delivery are handled separately by Whop. We do not store card numbers on this server and do not confirm payments from an outbound click. Whop processes information under its own policies and terms. Our hosting and, when configured, email delivery providers process data as needed to operate this site and handle messages. Processing may involve countries outside your own; applicable contractual or other lawful safeguards must be used where required.

## Retention and security

We retain contact messages only as long as needed to handle an enquiry, resolve disputes, and meet applicable recordkeeping duties. The operator periodically reviews and deletes messages that are no longer needed. Security includes access controls, encrypted connections when HTTPS is enabled, protected administrator credentials, and restricted storage. No service can promise absolute security.

## Your choices and rights

Depending on your location, you may have rights to access, correct, delete, restrict, or obtain a copy of personal data, object to certain processing, or complain to your local supervisory authority. Contact [contact@emotionalspending.com](mailto:contact@emotionalspending.com) to submit a request. We may need proportionate information to verify identity before responding. Withdrawing any consent does not affect earlier lawful processing.

## Operator and changes

Emotional Spending operates this website. For privacy enquiries and operator information, contact [contact@emotionalspending.com](mailto:contact@emotionalspending.com). We may update this notice when practices or legal requirements change. Review this page for the current notice.
TEXT;
    $add('terms-of-use','legal',['eyebrow'=>'THE PRACTICAL DETAILS','title'=>'Terms of use','body'=>$terms]);$add('privacy-policy','legal',['eyebrow'=>'YOUR PRIVACY MATTERS','title'=>'Privacy policy','body'=>$privacy]);
    $s=$db->prepare('INSERT INTO sections (page_slug,kind,content,position,visible) VALUES (?,?,?,?,?)');foreach($sections as $section)$s->execute($section);
    $faqs=[
        ['What is emotional spending?','Emotional spending is buying influenced by how we feel—such as stress, boredom, excitement, or a wish for comfort—rather than only what we need. An occasional emotional purchase is not a diagnosis. The aim here is to understand patterns, without judgment.'],
        ['Who is this workbook for?','Adults who want to explore impulse shopping, emotional buying triggers, and more intentional spending boundaries. You don’t need specialist financial knowledge.'],
        ['How is it different from a budgeting planner?','A budgeting planner helps organize numbers. This workbook focuses on the thoughts, emotions, and habits that can influence what happens before a purchase. The two can complement each other.'],
        ['Is the approach research-informed?','The planned approach draws on behavioral science and consumer psychology. Research on underlying concepts does not clinically validate this workbook or guarantee financial outcomes. Final workbook content and references will be verified before release.'],
        ['Do I need financial knowledge?','No specialist financial knowledge is needed. The activities focus on noticing patterns and reflecting on everyday decisions.'],
        ['How much time will I need?','The planned daily activities are designed around short reflection sessions, generally five to fifteen minutes. Your pace and completion time may vary.'],
        ['Will I receive both PDF editions?','A printable edition and a separate fillable edition are planned. Purchase remains unavailable until both files and the delivery process have been verified. The live product description and checkout will confirm exactly what is included.'],
        ['Is this a physical book?','No. This is a digital PDF workbook. No physical book will be shipped.'],
        ['How will I access my files?','Once checkout opens, successful purchases will receive access through the configured Whop delivery area. We’ll confirm the delivery instructions before accepting purchases.'],
        ['What is the refund policy?','Digital purchases are generally final once access is supplied, subject to applicable consumer rights and Whop’s buyer protections. Contact us about delivery problems, incorrect files, or a product that is not as described. See our Terms of Use for details.'],
        ['Can this replace professional support?','No. This is general education, not financial therapy, individualized financial advice, or mental health treatment. If spending is causing serious distress or harm, consider qualified professional support.'],
    ];
    $s=$db->prepare('INSERT INTO faqs (question,answer,position,visible) VALUES (?,?,?,1)');foreach($faqs as $i=>$faq)$s->execute([$faq[0],$faq[1],$i]);
    seed_posts($db);
}
function seed_posts(PDO $db): void {
    $posts = [
        ['Why do we shop when we’re stressed?','why-we-shop-when-stressed','Spending & emotions','A purchase can feel like a little relief. Understanding that feeling is a more useful starting point than judging it.',<<<'BODY'
You close your laptop after a difficult day, reach for your phone, and find yourself browsing. You weren’t looking for anything in particular. For a moment, choosing something new feels easier than sitting with the day you’ve had.

If that sounds familiar, try approaching it with curiosity. An emotionally influenced purchase does not make you irresponsible. It can be a clue about what you needed in that moment.

## Look at the moment before the purchase

Ask yourself what was happening before you started browsing. Were you tired, frustrated, overstimulated, or looking for a sense of control? Sometimes the appeal is the item itself. Sometimes it is the distraction, anticipation, or feeling of making a choice.

It is useful to separate the immediate feeling from the later consequences. A purchase might feel comforting and still be poorly timed for your budget. Those experiences can coexist. Noticing them gives you information rather than a reason to criticize yourself.

## Try a small experiment

The next time you notice an urge after a stressful moment, write down three things: what happened, how you feel, and what you hope buying will change. You do not need to write an essay. A few honest words are enough.

Then try one alternative that addresses the same need. If you need rest, take a short break. If you need connection, send a message. If you want something pleasant to anticipate, plan a small activity. These are experiments, not rules that must work every time.

## Give the decision some space

For a nonessential item, consider revisiting it tomorrow. A delay does not require you to say no forever; it gives you a chance to decide when the feeling is less immediate. You may still choose to buy it, and that can be a considered choice.

If spending is affecting your ability to meet essential needs or causing serious distress, seek qualified financial or mental health support. A reflection tool can help you notice patterns, but it cannot resolve every situation on its own.
BODY],
        ['Get to know your emotional spending triggers','recognize-emotional-spending-triggers','Everyday awareness','A trigger isn’t a character flaw. It’s a pattern you can start to notice—and understand.',<<<'BODY'
A trigger is something that tends to come before an urge to spend. It might be a feeling, a time of day, a notification, a social situation, or a combination of several things. Understanding your own pattern is more useful than assuming every impulse has the same cause.

## Start with observation

For a few days, make a short note when you feel drawn toward an unplanned purchase. Record what was happening, the feeling you noticed, and what you expected the purchase to offer. Include urges you did not act on. Those moments are just as informative as completed purchases.

Try to describe the situation specifically. “Tuesday evening, tired after work, scrolling a sale email” tells you more than “I have no discipline.” The first description gives you something to work with. The second makes a judgment without explaining the pattern.

## Look for repeated combinations

You might notice that shopping is more appealing when you are both tired and bored. Or that comparison appears after certain social feeds. Or that a limited-time message makes an ordinary item feel urgent. Your patterns may also change across weeks and circumstances.

Choose one repeated situation to explore. Ask what need seems to be present, what buying promises to provide, and whether there is another practical response available. Do not assume that every purchase is unnecessary or that every emotion needs correcting.

## Change one small cue

If a sale email repeatedly sends you browsing, consider unsubscribing. If saved payment details make late-night purchases very easy, remove them. If you shop when you need a break, plan another break option before that moment arrives.

These adjustments are not punishments. They are ways to make a deliberate decision a little easier. Review what happens without expecting perfection. The goal is not to eliminate every urge; it is to recognize more of them in time to choose.
BODY],
        ['The quiet power of a pause before you buy','pause-before-you-buy','Practical tools','You don’t have to decide right now. A little time can make room for a more considered choice.',<<<'BODY'
An urge can make a purchase feel like a decision that needs to happen immediately. A thoughtful pause offers another possibility: you can come back to it. That small change in timing gives you space to notice more than the excitement or discomfort of the moment.

## A pause is not a permanent no

For a nonessential purchase, choose a delay that fits the decision. A small item might wait until tomorrow. A bigger commitment may deserve several days and a look at your priorities. Essential needs and genuine time-sensitive obligations require a different approach.

During the pause, avoid repeatedly checking the product page. Save a simple note with the item, the price, and the reason you wanted it. Then step away. The purpose is to create room for reflection, not turn waiting into another form of browsing.

## Ask three useful questions

What am I feeling right now? What am I hoping this purchase will do for me? Does the decision still fit my priorities and available money? You might also ask whether you would want the item without the promotion, countdown, or comparison that first caught your attention.

There is no special answer that makes a purchase correct. The questions simply make more of the decision visible. You can decide to buy, wait longer, or choose something else.

## Review the experience kindly

Afterward, note what helped and what did not. Maybe a short walk was useful. Maybe the urge remained, but looking at the total cost changed your decision. Maybe you made the purchase and would make the same choice again. Each result can teach you something.

Reflection and purchase delays are educational tools, not clinically validated treatment. If spending feels beyond your control or is causing harm, a qualified professional can offer support suited to your circumstances.
BODY],
        ['Spending boundaries that leave room for life','spending-boundaries-without-giving-up-everything','Lasting routines','A useful boundary supports what matters to you. It doesn’t have to remove every small pleasure.',<<<'BODY'
A spending boundary is most useful when it reflects your actual life. A rule that ignores your responsibilities, resources, or sources of enjoyment may be difficult to maintain and tell you little about what would work better.

Start by identifying what needs protecting: essential costs, a bill due soon, a savings goal, or simply some breathing room. If your income does not cover essential needs, the issue is not solved by a better shopping rule. Practical financial support may be more appropriate.

## Choose something specific

“Spend less” is difficult to apply in a particular moment. “I will review nonessential purchases over this amount the next day” is easier to understand. So is “I will check my available discretionary money before opening a sale email.” The amount and timing should be yours to choose.

Build in room for things you value when your circumstances allow. An intentional pleasure is not a failure. A boundary can help distinguish a purchase you want from a decision made mainly to escape an uncomfortable feeling.

## Plan for the difficult moment

Think about a situation in which you often cross your own boundary. Make a simple if-then plan: if I start browsing after a frustrating workday, then I will take a break before deciding. Keep the alternative realistic and available. A plan that depends on a perfect evening is unlikely to be useful on a difficult one.

## Adjust rather than abandon

At the end of a week, ask whether the boundary was clear, practical, and compatible with your needs. If it was not, change it. If you did not follow it, look at what happened before the decision instead of treating the week as ruined.

The aim is an adaptable routine, not complete control over every feeling. Small, repeated observations can help you understand which choices support you—and where you may need additional help.
BODY],
    ];
    $s=$db->prepare('INSERT INTO posts (title,slug,category,excerpt,body,image,status,published_at,author,seo_title,seo_description,updated_at) VALUES (?,?,?,?,?,?,?, ?,?,?,?,?)');
    foreach($posts as $i=>$v) { $date=gmdate('Y-m-d',strtotime('-'.($i*4).' days'));$s->execute([$v[0],$v[1],$v[2],$v[3],$v[4],'/assets/journal-'.($i%3+1).'.svg','published',$date,'','',$v[3],gmdate('c')]); }
    foreach(['Spending & emotions','Everyday awareness','Practical tools','Lasting routines'] as $cat)$db->prepare('INSERT INTO categories (name) VALUES (?)')->execute([$cat]);
}
