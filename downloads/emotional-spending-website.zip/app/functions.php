<?php
declare(strict_types=1);
function e(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function db(): PDO {
    static $db;
    global $config;
    if ($db) return $db;
    $db = new PDO($config['dsn'], $config['db_user'], $config['db_password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') { $db->exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000'); }
    try { $db->query('SELECT key_name FROM settings LIMIT 1'); }
    catch (PDOException $ex) {
        if (!in_array((string)$ex->getCode(), ['HY000','42S02'], true)) throw $ex;
        $sql = file_get_contents(ROOT . '/database/schema.sql');
        if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') $sql = str_replace('INTEGER PRIMARY KEY AUTO_INCREMENT', 'INTEGER PRIMARY KEY AUTOINCREMENT', $sql);
        $db->exec($sql);
    }
    if (!$db->query('SELECT COUNT(*) FROM settings')->fetchColumn()) seed($db);
    return $db;
}
function query(string $sql, array $params = []): PDOStatement { $s=db()->prepare($sql); $s->execute($params); return $s; }
function setting(string $key, string $default = ''): string {
    static $cache;
    if ($cache === null) $cache = query('SELECT key_name, value FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR);
    return $cache[$key] ?? $default;
}
function set_setting(string $key, mixed $value): void {
    $value = is_array($value) ? json_encode($value, JSON_THROW_ON_ERROR) : (string)$value;
    if (query('SELECT key_name FROM settings WHERE key_name=?',[$key])->fetch()) query('UPDATE settings SET value=? WHERE key_name=?',[$value,$key]);
    else query('INSERT INTO settings (key_name,value) VALUES (?,?)',[$key,$value]);
}
function data(string $key, array $default=[]): array { $decoded=json_decode(setting($key),true);return is_array($decoded)?$decoded:$default; }
function csrf(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf()).'">'; }
function verify_csrf(): void {
    if (!is_string($_POST['csrf']??null) || !hash_equals(csrf(), $_POST['csrf'])) { http_response_code(419); throw new RuntimeException('Your session expired. Reload the form and try again.'); }
}
function redirect(string $url): never { header('Location: '.$url, true, 303); exit; }
function flash(string $text, string $type='success'): void { $_SESSION['flash']=['text'=>$text,'type'=>$type]; }
function safe_url(string $url, string $fallback=''): string {
    if (preg_match('~^/(?!/)[^\x00-\x20\\\\]*$~u',$url)) return $url;
    if (filter_var($url,FILTER_VALIDATE_URL) && in_array(strtolower(parse_url($url,PHP_URL_SCHEME)??''),['https','http'],true) && !parse_url($url,PHP_URL_USER) && !parse_url($url,PHP_URL_PASS)) return $url;
    if (str_starts_with($url,'mailto:') && filter_var(substr($url,7),FILTER_VALIDATE_EMAIL)) return $url;
    return $fallback;
}
function whop_url(string $url): bool {
    $p=parse_url($url);
    return filter_var($url,FILTER_VALIDATE_URL) && ($p['scheme']??'')==='https' && in_array(strtolower($p['host']??''),['whop.com','www.whop.com'],true) && empty($p['user']) && empty($p['pass']) && empty($p['port']) && preg_match('~^/checkout/[A-Za-z0-9_-]+/?$~',$p['path']??'');
}
function ready(): bool { return setting('availability')==='available' && whop_url(setting('checkout_url')) && setting('content_verified')==='1' && setting('printable_ready')==='1' && setting('fillable_ready')==='1'; }
function price(): string { return (setting('currency','USD')==='USD'?'$':setting('currency').' ') . number_format((float)setting('price','27.99'),2); }
function purchase(string $label='',string $class='button'): string {
    return '<a class="'.e($class).'" href="'.(ready()?'/checkout':'/our-workbook#availability').'">'.e($label ?: (ready()?setting('cta_text','Get my workbook').' · '.price():'Explore the workbook')).'<span aria-hidden="true">↗</span></a>';
}
function image_url(string $url, string $fallback='/assets/book-cover.svg'): string {
    return preg_match('~^/(assets|uploads)/[a-zA-Z0-9_./-]+\.(svg|png|jpe?g|webp)$~',$url) ? $url : $fallback;
}
function inline_text(string $text): string {
    $text=e($text);
    $text=preg_replace('/\*\*(.+?)\*\*/s','<strong>$1</strong>',$text);
    return preg_replace_callback('~\[([^\]]+)\]\(([^)]+)\)~',function($m){ $url=html_entity_decode($m[2],ENT_QUOTES); return safe_url($url) ? '<a href="'.e($url).'" rel="noopener noreferrer">'.$m[1].'</a>' : $m[1]; },$text);
}
function prose(string $text): string {
    $out=''; $list=false;
    foreach (preg_split('/\R\s*\R/', trim($text)) as $block) {
        $block=trim($block); if ($block==='') continue;
        if (str_starts_with($block,'## ')) $out.='<h2>'.inline_text(substr($block,3)).'</h2>';
        elseif (str_starts_with($block,'### ')) $out.='<h3>'.inline_text(substr($block,4)).'</h3>';
        elseif (str_starts_with($block,'- ')) { $out.='<ul>'; foreach(preg_split('/\R/',$block) as $line) $out.='<li>'.inline_text(preg_replace('/^- /','',$line)).'</li>'; $out.='</ul>'; }
        else $out.='<p>'.nl2br(inline_text($block)).'</p>';
    }
    return $out;
}
function section_data(string $slug): array { return query('SELECT * FROM sections WHERE page_slug=? AND visible=1 ORDER BY position,id',[$slug])->fetchAll(); }
function is_admin(): bool { return !empty($_SESSION['admin_id']); }
function audit(string $action): void { query('INSERT INTO audit_logs (admin_id,action,created_at) VALUES (?,?,?)',[(int)($_SESSION['admin_id']??0),$action,gmdate('c')]); }
function rate_key(string $action): string { return hash('sha256',$action.'|'.($_SERVER['REMOTE_ADDR']??'cli')); }
function rate_limited(string $action,int $maximum,int $seconds,bool $increment=true): bool {
    query('DELETE FROM rate_limits WHERE expires_at<=?',[time()]);
    $key=rate_key($action); $row=query('SELECT * FROM rate_limits WHERE key_name=?',[$key])->fetch();
    if ($row && (int)$row['expires_at']>time() && (int)$row['attempts']>=$maximum) return true;
    if ($increment) {
        if (!$row) query('INSERT INTO rate_limits (key_name,attempts,expires_at) VALUES (?,1,?)',[$key,time()+$seconds]);
        elseif ((int)$row['expires_at']<=time()) query('UPDATE rate_limits SET attempts=1,expires_at=? WHERE key_name=?',[time()+$seconds,$key]);
        else query('UPDATE rate_limits SET attempts=attempts+1 WHERE key_name=?',[$key]);
    }
    return false;
}
function private_key(): string {
    $file=ROOT.'/storage/app.key';
    if (!is_file($file)) { $handle=@fopen($file,'x'); if($handle) { fwrite($handle,random_bytes(32)); fclose($handle); chmod($file,0600); } }
    $key=file_get_contents($file); if(strlen($key)!==32) throw new RuntimeException('Invalid application encryption key.'); return $key;
}
function encrypt_secret(string $value): string { $iv=random_bytes(12);$tag='';$cipher=openssl_encrypt($value,'aes-256-gcm',private_key(),OPENSSL_RAW_DATA,$iv,$tag);return base64_encode($iv.$tag.$cipher); }
function decrypt_secret(string $value): string { $raw=base64_decode($value,true);if(!$raw||strlen($raw)<28)return '';return openssl_decrypt(substr($raw,28),'aes-256-gcm',private_key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16))?:''; }
function notification(int $id,array $message): string {
    if (setting('smtp_host')==='') return 'not-configured';
    try {
        require_once ROOT.'/vendor/autoload.php';
        $mail=new PHPMailer\PHPMailer\PHPMailer(true);$mail->isSMTP();
        $mail->Host=setting('smtp_host');$mail->Port=(int)setting('smtp_port','587');
        $mail->SMTPAuth=setting('smtp_user')!=='';$mail->Username=setting('smtp_user');$mail->Password=decrypt_secret(setting('smtp_password'));
        $mail->SMTPSecure=setting('smtp_security','tls');$mail->Timeout=10;
        $mail->setFrom(setting('smtp_from',setting('contact_email')),'Emotional Spending');
        $mail->addAddress(setting('contact_email'));$mail->addReplyTo($message['email'],$message['name']);
        $mail->Subject='Website message: '.$message['subject'];$mail->Body=$message['name']."\n".$message['body'];$mail->send();return 'sent';
    } catch(Throwable $ex) { error_log('Contact SMTP notification failed for message '.$id);return 'failed'; }
}
