<?php
declare(strict_types=1);
header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex, nofollow');
require ROOT.'/app/admin-actions.php';
$route=substr($path,6)?:'dashboard';$route=trim($route,'/');
$hasAdmin=(bool)query('SELECT id FROM admins LIMIT 1')->fetch();
$authError='';
if(in_array($route,['login','setup'],true)) {
    if($route==='setup'&&$hasAdmin)redirect('/admin/login');
    if(is_admin())redirect('/admin');
    if($_SERVER['REQUEST_METHOD']==='POST') {
        try {
            verify_csrf();
            if(rate_limited($route,8,900))throw new RuntimeException('Too many attempts. Please wait 15 minutes before trying again.');
            $email=trim(input('email',190));$password=input('password',1024);
            if($route==='setup') {
                $token=$config['setup_token']?:trim(is_file(ROOT.'/storage/setup-token.txt')?file_get_contents(ROOT.'/storage/setup-token.txt'):'');
                if(strlen($token)<32||!hash_equals($token,input('setup_token',512)))throw new RuntimeException('The setup token is not valid. Use the private token from your server configuration.');
                if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Enter a valid administrator email address.');
                if(strlen($password)<12)throw new RuntimeException('Choose a password with at least 12 characters.');
                db()->beginTransaction();
                if(query('SELECT id FROM admins LIMIT 1')->fetch())throw new RuntimeException('Administrator setup has already been completed.');
                query('INSERT INTO admins (email,password_hash,created_at) VALUES (?,?,?)',[$email,password_hash($password,PASSWORD_DEFAULT),gmdate('c')]);db()->commit();
                if(is_file(ROOT.'/storage/setup-token.txt'))unlink(ROOT.'/storage/setup-token.txt');
                flash('Administrator created. Setup is now locked. Please sign in.');redirect('/admin/login');
            }
            $admin=query('SELECT * FROM admins WHERE email=?',[$email])->fetch();
            if(!$admin||!password_verify($password,$admin['password_hash']))throw new RuntimeException('We couldn’t sign you in with those details.');
            if(password_needs_rehash($admin['password_hash'],PASSWORD_DEFAULT))query('UPDATE admins SET password_hash=? WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$admin['id']]);
            $_SESSION=[];session_regenerate_id(true);$_SESSION['admin_id']=(int)$admin['id'];$_SESSION['last_active']=time();query('DELETE FROM rate_limits WHERE key_name=?',[rate_key('login')]);audit('Administrator signed in');redirect('/admin');
        } catch(Throwable $ex) { if(db()->inTransaction())db()->rollBack();$authError=$ex instanceof RuntimeException&&!$ex instanceof PDOException?$ex->getMessage():'We couldn’t complete that request. Please try again.'; }
    }
    include ROOT.'/templates/admin-auth.php';exit;
}
if(!is_admin())redirect($hasAdmin?'/admin/login':'/admin/setup');
if($_SERVER['REQUEST_METHOD']==='POST') {
    try { verify_csrf();admin_action(); }
    catch(Throwable $ex) {
        if(db()->inTransaction())db()->rollBack();
        error_log('Admin action failed: '.$ex->getMessage());
        flash($ex instanceof RuntimeException&&!$ex instanceof PDOException?$ex->getMessage():'The change could not be saved. Please try again.','error');
    }
    if(http_response_code()===419){$authError='Your session expired. Please reload this page.';http_response_code(419);}
    else redirect($path.(!empty($_SERVER['QUERY_STRING'])?'?'.$_SERVER['QUERY_STRING']:''));
}
if($route==='preview') {
    $post=query('SELECT * FROM posts WHERE id=?',[(int)($_GET['id']??0)])->fetch();
    if(!$post){http_response_code(404);exit('Article not found.');}
    $noindex=true;$config['base_url']=setting('base_url',$config['base_url']);require ROOT.'/templates/article.php';exit;
}
$allowed=['dashboard','pages','product','posts','media','navigation','theme','settings','inbox','password'];
if(!in_array($route,$allowed,true)){http_response_code(404);$route='not-found';}
include ROOT.'/templates/admin.php';
