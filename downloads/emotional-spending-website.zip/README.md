# Emotional Spending

A responsive editorial storefront and real PHP content management system. PHP 8.2+, PDO MySQL/MariaDB for IONOS, SQLite for local development, vanilla JavaScript, local fonts, no Node server or build process in production. PHPMailer production dependencies are included in the release ZIP.

## Run locally

```sh
# In this cloud workspace, first activate PHP:
. /workspace/.php-dev/enable.sh
cd /workspace/dude
php bin/install.php
php -S 127.0.0.1:8000 -t public router.php
```

The web root must be `public/`. Open the local server in your own browser. Go to `/admin/setup`, read the private `storage/setup-token.txt` file on the server, and use it to create your own administrator email and strong password. No public/default administrator password is included. Setup locks immediately after account creation; the local token file is removed. Subsequent sign-ins use `/admin/login`.

## Included

- Home, About, dedicated workbook page, journal, four original starter articles, contact, terms, privacy, meaningful 404 and safe 500 handling.
- Database-connected page/section editor with ordering, visibility, rich text, repeatable content items, SEO, and images.
- Product/price/currency/Whop settings, edition verification gates, reorderable authentic previews, FAQ management.
- Blog creation, drafts, scheduled publication, private saved previews, deletion, categories, images, SEO.
- Media upload validation, random filenames, alt descriptions, reference-aware deletion, no executable/SVG/PDF uploads.
- Navigation/footer/legal/social editing, accessible theme color validation, local font choices, logo and sharing image selectors.
- Private searchable contact inbox with read/unread/resolved states; optional encrypted SMTP credentials and PHPMailer notifications.
- Secure password hashing, session rotation/timeout, one-time setup, CSRF protection, rate limiting, escaped/safely formatted content, prepared queries, security headers.
- Sitemap, robots, canonical/OG metadata, Book/BlogPosting structured data without invented reviews or ratings.

## Important release state

**This is a working website implementation, not a confirmed live commercial launch.** Only the website brief was supplied. The actual 48-page PDF, original logo, final cover, fillable edition, checkout link, IONOS account, legal operator identity, and SMTP credentials were not supplied. The cover and journal artwork are original provisional editorial illustrations; the site labels the cover and format demonstrations honestly. They are not extracted workbook pages. No full paid PDF is publicly hosted. No citations or scientific reference list is invented.

Checkout is closed by default. It opens only when an administrator supplies a valid official Whop checkout link, selects Available, and confirms source-content review and both tested delivery files. These confirmations are operator attestations, not an API verification. Whop remains the payment/delivery provider; this website never stores card details, claims an outbound click is a sale, or unlocks a file after a browser redirect.

See [IONOS deployment](docs/IONOS.md), [content management](docs/CONTENT-MANAGEMENT.md), and the [testing report](docs/TESTING.md).

## Development checks

The following commands refer to the development source checkout. Runtime ZIPs intentionally exclude Python packaging helpers and the browser-test harness; these are not required on your hosting account. For Hostinger, use the dedicated Hostinger archive and [Hostinger guide](docs/HOSTINGER.md) with File Manager rather than a backup-migration tool.

```sh
find app templates public bin -name '*.php' -print0 | xargs -0 -n1 php -l
node tests/browser.cjs
php bin/export-seed.php
python3 bin/package.py
```

The browser suite is development-only and requires Node, Playwright, and Chromium. It starts a loopback PHP server with an isolated SQLite database, creates a random temporary administrator, and tests real forms and CMS operations. It does not send email or make purchases. For MariaDB testing, supply a **fresh disposable** database in `TEST_DB_DSN` and `ES_DB_USER`/`ES_DB_PASSWORD`; never point these tests at live content. Production requires no Node/npm commands.

The package generator includes compiled/static assets, production PHP dependencies, schema, starter content, and guides. It excludes Git metadata, environment secrets, sessions, databases, setup tokens, test uploads, and screenshots. Do not publish `config.local.php`, `storage/`, or paid PDFs under the web root.
