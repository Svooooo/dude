# Testing report

Tested on 4 November 2026. These are implementation checks in this cloud environment, not confirmation of a live IONOS deployment or paid product delivery.

## Passed

- PHP syntax checks for all application, template, public-entry, and CLI PHP files on PHP 8.4.27.
- Full browser suite: **17 functional groups** using Chromium with an isolated SQLite database, and the same suite against a fresh private MariaDB 11.8.6 database through PDO MySQL.
- Home, About, Workbook, Journal, Contact, Terms, Privacy, four seeded article routes, and a meaningful 404. Canonical/meta/sitemap/robots routes respond correctly.
- Mobile navigation open/close, Escape and focus restoration; reflection tab keyboard arrows; native FAQ disclosure; no horizontal overflow at 390 px for primary pages; desktop screenshots at 1440 px.
- Contact invalid-field responses, invalid-CSRF response (419), valid submission, database inbox persistence, search, escaped message content, and status changes. With SMTP absent, the message still saves and does not claim an email was sent.
- Protected CMS redirects, random one-time admin setup, password-hash login, locked setup after creation, all CMS screens, structured page editing, escaped text, central price updates, safe URL checks, launch gating, image upload, real preview/lightbox controls, article create/publish/delete, safe rich text, legal-page editing, navigation changes, contrast validation, CSRF protection, and sign-out.
- All enabled purchase CTAs route to the same configured checkout redirect. This was tested with an explicitly synthetic destination in a disposable database; the request was not followed to Whop and no payment was attempted or claimed.
- Direct public requests for private configuration/database paths return 404 under the documented public document root.
- Standalone `database/schema.sql` and starter `database/seed.sql` imports through the MariaDB client: six editable pages, four original articles, 25 starter sections, no administrator credentials. Application initialization/seeding also works through PDO MySQL.
- axe-core automated WCAG 2 A/AA and WCAG 2.1 AA checks: zero detected violations on Home, Workbook, Contact, Journal, and first-time administrator setup after correcting contrast and link names. This is not a full accessibility certification or a substitute for assistive-technology testing.
- Desktop/mobile visual inspection and loaded image checks: no broken images or overflow detected. Locally hosted WOFF2 fonts reduce the primary font payload to approximately 115 KB.
- Release ZIP integrity and secret/runtime-state exclusion checks. Production SMTP dependencies are included. The complete 17-group browser suite also passed from a separately extracted copy of the release ZIP using a fresh SQLite database.
- The dedicated Hostinger runtime archive also passed all 17 groups from its extracted `public_html` plus sibling private-directory layout, including actual media upload. Static archive checks exclude Python/Node test scripts, TypeScript, ASP.NET files, credentials, and runtime databases. This does not establish acceptance by Hostinger's migration tool or replace a live hosting test.

## Problems found and corrected

- The non-root PHP installation initially pointed to an unavailable system session directory. Sessions now use private project storage with restrictive permissions and garbage collection.
- Corrected literal line-break text in starter headings, missing query-string notices on CMS redirects, and metadata warnings on missing article routes.
- Added accessible names to image links and improved low-contrast secondary text. The rich-text toolbar is separate from its textarea label.
- Preserved empty repeatable lists, unique reflection IDs, and cache-versioned theme updates. Starter SQL export is isolated from all live configuration/data.

## Not performed / externally blocked

- **Workbook analysis:** the actual 48-page PDF and original logo were not supplied. No genuine cover/page extraction, exact research-reference verification, or assessment of the source workbook occurred. Site copy is based on the supplied brief and must be checked against the original before launch. All initial cover/format illustrations are openly provisional, and genuine preview galleries remain empty by default.
- **Fillable PDF:** not supplied, created, or tested. No live claim that a tested fillable file is available is made. Printable and fillable delivery confirmations default to false.
- **Whop:** no account, real checkout URL, plan, buyer flow, immediate-digital-delivery consent, payment, refund, or gated Files delivery was tested. Access to the official docs host was denied by the network policy. The implemented integration is a validated hosted-link configuration only, not embedded checkout, API price synchronization, payment webhooks, or verified fulfillment.
- **IONOS/Apache:** no hosting credentials or domain controls were supplied. Real IONOS PHP settings, Apache rewrite/authorization behavior, document-root assignment, permissions, DNS, HTTPS, email reputation, production backups, and remote database credentials require deployment verification. Local PHP routing is not an Apache compatibility test.
- **SMTP:** no provider credentials were supplied. PHPMailer 7.1.1 is bundled; real email sending, authentication, TLS negotiation with a provider, and delivery were not tested. No external messages were sent during QA.
- **Dependency vulnerability audit:** `composer audit` was attempted but the network policy denied `packagist.org/api/security-advisories/`. Dependency vulnerability status is **unverified**, not passed. Run the audit from a permitted network before launch. No TLS, package signatures, or checksums were bypassed.
- No real-device Safari/iOS/Android test, manual screen-reader audit, penetration test, real-world Core Web Vitals measurement, paid-product content review, or professional legal review was performed.

## Reproduce

See `tests/browser.cjs` in the development source checkout and the README. Tests create temporary content and a random account in a disposable database, use no real payments/SMTP, and remove their uploaded fixture and temporary SQLite data. Never run this suite against a production database. Browser harnesses, Python packaging helpers, and screenshots are development artifacts excluded from runtime ZIPs.
