# IONOS deployment and launch

## 1. Hosting prerequisites

Use a supported IONOS **Linux PHP web-hosting** plan with PHP 8.2 or newer, MySQL/MariaDB, PDO MySQL, mbstring, fileinfo, OpenSSL, sessions, JSON, and Apache rewrite support. Enable HTTPS. This implementation was exercised locally on PHP 8.4.27 and MariaDB 11.8.6; the actual account/plan has not been accessed. Check the PHP versions/extensions offered by your plan. No Docker, Node server, Redis, or queue worker is required.

## 2. Database

In the IONOS control panel, open the database management area and create a MySQL/MariaDB database and strong database password. Record the **database hostname shown by IONOS**, database name, and username; shared-hosting database hosts are not necessarily localhost. Open its phpMyAdmin interface, select the database, and import `database/schema.sql`, then `database/seed.sql`, once into an empty database. The imports contain no administrator account or customer records.

Alternatively, if shell access is available, set your private configuration and run `php bin/install.php`; it creates missing tables and seeds an empty installation. Do not import starter content over an existing website. Back up the database before upgrades.

## 3. Upload and domain document root

Extract `emotional-spending-website.zip` locally. Upload all project files and directories into a private project directory such as `/emotional-spending` through IONOS File Manager or SFTP. Preserve dotfiles, including `.htaccess`. Do not upload an archive and leave it downloadable on your live site.

Assign emotionalspending.com and www.emotionalspending.com to **the project's `public` directory**, for example `/emotional-spending/public`. The domain URL is still the root `/`; `public` must not appear in visitor URLs. Keep `app`, `database`, `storage`, `vendor`, and configuration files outside the domain document root. Root and private-folder access-denial rules provide extra defense, but are not a substitute for the correct document root.

Recommended permissions are directories 755 and files 644, with private configuration and keys 600 where the hosting execution model allows it. Make `storage/` and `public/uploads/` writable by PHP without using world-writable 777. Session files are created in private `storage/sessions/` with directory mode 700. Uploaded images are random-named, validated JPEG/PNG/WebP; paid PDFs are never accepted in the media library.

## 4. Private configuration

Copy `config.example.php` to `config.local.php` in the project directory, **outside public**. Enter the real DSN, username, password, canonical HTTPS domain, and a unique random setup token of at least 32 characters. A password manager can generate the token. Never send these values in chat, commit them, or reuse a default value. The file returns a PHP array; preserve valid quoting.

If using CLI, `php bin/install.php` can instead generate the setup token in private `storage/setup-token.txt`. When using the web setup route on shared hosting, configure the token in the private configuration first. There is no unprotected web installer and no default admin password.

## 5. HTTPS and first administrator

Activate the domain's SSL certificate in IONOS. Enable the hosting panel's HTTPS redirect if supported, confirm that both domain variants reach the intended canonical domain, and test the certificate in a browser. Do not trust arbitrary forwarded headers or disable certificate validation.

Open `https://www.emotionalspending.com/admin/setup`. Enter the private setup token, your administrator email, and a unique password of at least 12 characters. Setup locks as soon as the first administrator exists. Clear `setup_token` in `config.local.php` afterward. A generated local token file is deleted automatically. Sign in at `/admin/login`; sign out with the dashboard control. Inactive sessions expire after 30 minutes. Use Account security for password changes. No email password-reset service is claimed.

## 6. Genuine product material and legal review

Upload the original undistorted logo, extracted actual book cover, and a limited selection of legible genuine preview-page **images** in Media library. Replace the concept cover and logo under Workbook / Visual theme. Add captions, descriptions, visibility, and order in Workbook & checkout. Do not put the full paid PDFs in `public` or media uploads.

Read all 48 pages and verify the chapter descriptions, original PAUSE wording, 30-day schedule, 90-day plan, and exact references against the source. Add accurately matched, checked DOI/reference records through the safe text editor if desired. The starter copy is based on the supplied brief only. Do not imply clinical validation of the workbook. Update provisional FAQ and edition copy to match actual availability.

Enter real business identity, address, jurisdiction, support email, and provider information in Site settings. Have Terms and Privacy reviewed against actual operation, applicable consumer rights, Whop's current buyer terms, retention obligations, and international transfers. Review/delete contact records on a documented retention schedule. No analytics or nonessential trackers are installed, so there is no cosmetic cookie banner. Adding tracking later requires actual consent/blocking implementation where applicable.

## 7. Whop hosted checkout and delivery

This implementation uses a stored **hosted checkout link**, with no API keys, webhook, embedded checkout, payment verification, or server-side fulfillment. All live purchase buttons use `/checkout`, which validates and redirects to the same configured official URL. A returning visitor is never treated as paid.

1. In your Whop account, create the actual product and a **one-time $27.99 USD** price. Confirm taxes, terms, any buyer-protection requirements, and refund/withdrawal settings. Website price editing does not change Whop.
2. Obtain an official product link under `https://whop.com/checkout/…`. Paste the real generated URL into Workbook & checkout. The validator rejects general `/network` destinations, other hosts, embedded credentials, non-HTTPS URLs, and empty checkout paths. If Whop changes official formats, verify current documentation before changing the validator; do not use an invented URL.
3. Use Whop's current Files or approved gated file-delivery functionality to grant successful purchasers access to **two separate real files**: printable PDF and fillable PDF. Verify availability/features in your account and consult Whop support if the plan does not offer the required delivery capability. No exact unverified dashboard controls or undocumented APIs are assumed here.
4. Test the printable file for completeness, readable US Letter printing, and the expected content. In a compatible PDF reader, enter answers in the fillable edition, save, close, and reopen it; verify field values, page count, multiline behavior, and any stated reuse permissions.
5. Perform an actual permitted test purchase using Whop's supported testing workflow or your own verified transaction. Confirm final price/currency, successful payment state, purchaser access, both correct files, support details, and refund behavior. Confirm that failed/cancelled payments do not grant access. Check required express consent/acknowledgement for immediate digital supply in applicable jurisdictions through the actual checkout process.
6. Confirm those checks in the CMS and choose Available only after they are complete. Correct the public edition descriptions, FAQs, genuine previews, and price to match the actual offer.

Official starting points: https://whop.com/ and https://docs.whop.com/. The environment denied access to the official documentation host during implementation; current account-specific delivery instructions and live checkout behavior therefore remain operator verification tasks. No claim of current embedded/API support is made.

## 8. Contact and SMTP

Contact messages save to the private database without email configuration. To enable notifications, use your verified SMTP provider's host, port 587/STARTTLS or 465/implicit TLS, username, password, and verified sender address in Site settings. Save and use Send test notification. SMTP passwords are encrypted with private `storage/app.key`; back up that key securely with the database. The interface never echoes the stored password. If notifications fail, the message remains in the inbox with its delivery status; examine the private PHP error log and provider settings. Do not disable TLS checks to fix delivery.

## 9. Launch checks

- Visit every navigation/legal page, four articles, sitemap, and a missing route. Verify clean URLs, correct canonical domain, HTTPS, no PHP warnings, and expected 404 status.
- Check desktop, tablet, and a real phone: text, image proportions, focus outlines, mobile drawer/Escape, FAQs, reflection tabs, real-page gallery/lightbox, and keyboard navigation.
- Submit an invalid then valid contact form. Verify server-side errors, saved message, inbox search/status changes, and actual SMTP notification if configured.
- Sign in/out; verify private pages redirect when signed out; verify `/admin/setup` is locked. Do not expose the ZIP, SQL, config, SQLite, session, log, or key files publicly.
- Test all purchase CTAs against the same actual configured URL; confirm the checkout amount and both digital deliveries independently. Do not infer a sale from a redirect.
- Run a dependency vulnerability audit from a permitted network, and maintain PHP, hosting patches, and Composer dependencies. Back up private files, uploads, and the database regularly.

## Troubleshooting

- **403 at domain root:** confirm domain target is `public/`, not the project root, and that public `.htaccess` was uploaded.
- **500/blank page:** inspect private PHP/IONOS logs. Check credentials, PDO MySQL availability, private config syntax, folder permissions, and PHP version. Errors never echo database passwords to visitors.
- **Only homepage works:** check Apache rewrite support and `public/.htaccess`.
- **Cannot sign in/form expires:** ensure PHP can write `storage/sessions`; reload to get a fresh CSRF token. Check browser cookie settings and HTTPS.
- **Theme not updated:** new theme versions are cache-keyed. Clear an upstream page cache if your hosting account adds one.
- **No email:** open the inbox first; check notification status and SMTP configuration. Saving a message does not require SMTP.
