# Managing your website

Sign in at `/admin/login` using the administrator you created. Use View website to see saved content. There is no public administrator password.

## Overview

Shows actual database page/article/message counts, launch configuration, and an audit trail. It does **not** show fake sales, invented visitors, or payment totals. A checkout link is not a payment integration.

## Pages & sections

Choose Home, About, Workbook, Contact, Terms, or Privacy. Change the SEO title and description; uncheck Published to remove a page from public routes and the sitemap. Open individual sections to edit headings, body, links, and supported images/content items. Use ↑ ↓ to reorder sections or repeatable items. Visibility controls hide a section without deleting it. Add new sections hidden, review them, then enable them. Removal is confirmed before saving.

The long-form editor supports ordinary paragraphs, `## Heading`, `### Smaller heading`, `**bold**`, `- list items`, and `[link label](https://destination.example)`. Toolbar buttons help insert formatting. This is intentionally safe rich text, not arbitrary HTML. HTML/code is displayed as text; JavaScript links are rejected. Save the page to publish edits. The first editorial text section supplies the page H1; later sections use H2.

Purchase CTAs always use the central live checkout when sales are enabled. While checkout is closed, configurable informational buttons can take readers to the workbook/another valid destination. Keep all copy consistent with the actual product.

## Workbook & checkout

Edit the real product name/subtitle, descriptions, cover, page count, included-feature list, format explanations, central price/currency, and purchase button text. Prices update website displays centrally. **Update and verify the Whop price separately.** Optional plan ID is a reference field only; there is no silent API price sync.

Enter the official HTTPS Whop product checkout link. General marketplace/network links are rejected. Preparing and Unavailable keep checkout closed. Available requires confirmation that source copy was checked and both genuine PDFs were tested and delivered through Whop. The site does not independently inspect those files. Do not check confirmations merely to enable a button.

For previews, upload selected actual page images in Media library, then add each under Authentic workbook previews. Captions, numeric order, visibility, and deletion are editable. Preview images open in a keyboard-accessible modal. No paid PDFs are accepted by the media uploader.

The FAQ editor changes shared questions/answers used on home and the product page. Reorder, hide, remove, or add entries. Update in-preparation language after genuine release verification.

## Journal

Create an article, choose a unique lowercase hyphenated slug, excerpt, safe rich-text body, category, optional author, cover, and metadata. Save as Draft for a private saved preview. Published future-dated articles stay private until their publication date (UTC). Preview opens the saved version; save before previewing edits. Delete only after confirming. Categories can be added; deleting a category moves its posts to Uncategorized. Starter articles have no invented expert biography or byline.

## Media library

Upload JPEG/PNG/WebP images up to 5 MB and 40 megapixels, with neither dimension over 12,000 px. Use meaningful alt descriptions. Filenames are generated, and executable files, SVG uploads, and PDFs are rejected. Images in use cannot be deleted; remove their references first. Authentic book material must replace provisional artwork before launch. Uploaded logos retain proportions.

## Navigation & footer

Edit labels, destinations, visibility, and ordering for primary and legal links. Footer navigation follows the same primary list. Add or remove social links; empty social entries are not shown. Change the footer description here. Contact email is in Site settings.

## Visual theme

Choose the palette, heading/body fonts, button shape, header spacing, logo width (100–240 px), logo, and sharing image. Color validation rejects body text/background and white button/primary combinations below 4.5:1. The assets are local; no third-party font tracking is loaded. For broad sharing-image support, use a real 1200×630 JPEG/PNG rather than the initial SVG.

## Site settings and inbox

Set the canonical HTTPS domain, brand, tagline, contact email, real legal identity/address/jurisdiction, and optional SMTP. Maintenance mode returns HTTP 503 to ordinary visitors while keeping the administrator accessible. Only essential cookies are used; no nonexistent tracking switches are shown.

Contact messages remain in the inbox even if an SMTP notification fails. Search by name, email, subject, or content. Open a message and explicitly mark it read, unread, or resolved. Deletion requires confirmation. Do not request card details or sensitive health/financial data. Follow your actual retention policy and privacy obligations.

Change your password under Account security. Sessions expire after 30 inactive minutes. Sign out when finished. Keep `config.local.php`, application encryption keys, backups, and administrator credentials private.
