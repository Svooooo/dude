<?php
// Copy to config.local.php, outside the public document root.
return [
    'dsn' => 'mysql:host=YOUR_IONOS_DB_HOST;dbname=YOUR_DATABASE;charset=utf8mb4',
    'db_user' => 'YOUR_DATABASE_USER',
    'db_password' => 'YOUR_DATABASE_PASSWORD',
    'base_url' => 'https://www.emotionalspending.com',
    // Set a unique random 32+ character value, open /admin/setup, then clear it.
    'setup_token' => '',
    'debug' => false,
];
