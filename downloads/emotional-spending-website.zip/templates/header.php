<?php
$brand=setting('brand','Emotional Spending');
$description=$description??'A more intentional relationship with spending.';
$canonical=rtrim($config['base_url'],'/').($path==='/'?'':$path);
$navigation=data('navigation');
$isArticle=isset($post)&&is_array($post);
$schema=['@context'=>'https://schema.org','@type'=>'WebSite','name'=>$brand,'url'=>rtrim($config['base_url'],'/')];
if($path==='/our-workbook') {
    $schema=['@context'=>'https://schema.org','@type'=>'Book','name'=>setting('product_name'),'description'=>setting('product_description'),'bookFormat'=>'https://schema.org/EBook','inLanguage'=>'en','numberOfPages'=>(int)setting('page_count'),'url'=>$canonical];
    if(ready())$schema['offers']=['@type'=>'Offer','price'=>setting('price'),'priceCurrency'=>setting('currency'),'availability'=>'https://schema.org/InStock','url'=>$canonical];
}
if($isArticle) {
    $schema=['@context'=>'https://schema.org','@type'=>'BlogPosting','headline'=>$post['title'],'description'=>$description,'datePublished'=>$post['published_at'],'dateModified'=>substr($post['updated_at'],0,10),'mainEntityOfPage'=>$canonical];
    if($post['author'])$schema['author']=['@type'=>'Person','name'=>$post['author']];
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> — <?= e($brand) ?></title><meta name="description" content="<?= e($description) ?>">
<link rel="canonical" href="<?= e($canonical) ?>"><meta property="og:title" content="<?= e($title) ?>"><meta property="og:description" content="<?= e($description) ?>"><meta property="og:type" content="<?= $isArticle?'article':'website' ?>"><meta property="og:url" content="<?= e($canonical) ?>"><meta property="og:image" content="<?= e(rtrim($config['base_url'],'/').image_url(setting('og_image'),'/assets/share.svg')) ?>"><meta name="twitter:card" content="summary_large_image">
<script type="application/ld+json" nonce="<?= e($cspNonce) ?>"><?= json_encode($schema,JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_THROW_ON_ERROR) ?></script>
<?php if(isset($noindex)&&$noindex): ?><meta name="robots" content="noindex,nofollow"><?php endif; ?>
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml"><link rel="preload" href="/assets/heading.woff2" as="font" type="font/woff2" crossorigin><link rel="stylesheet" href="/assets/site.css?v=1"><link rel="stylesheet" href="/theme.css?v=<?= substr(hash('sha256',implode('|',array_map(fn($key)=>setting($key),['primary_color','accent_color','background_color','text_color','heading_font','body_font','button_style','logo_size','header_layout']))),0,12) ?>"><script src="/assets/site.js" defer></script>
</head><body class="<?= e($bodyClass??'') ?>"><a class="skip-link" href="#main">Skip to content</a>
<div class="announcement"><?= e(setting('tagline')) ?> <span aria-hidden="true">✳</span></div>
<header class="site-header"><div class="header-inner">
<a class="brand" href="/" aria-label="Emotional Spending home"><?php if(setting('logo')): ?><img src="<?= e(image_url(setting('logo'))) ?>" alt="<?= e($brand) ?>" width="190" height="50"><?php else: ?><span class="brand-mark" aria-hidden="true">✳</span><span>emotional<span class="brand-second">spending</span></span><?php endif; ?></a>
<nav class="desktop-nav" aria-label="Main navigation"><?php foreach($navigation as $nav): if(empty($nav['visible']))continue; ?><a href="<?= e(safe_url($nav['url'],'/')) ?>" <?= $path===$nav['url']?'aria-current="page"':'' ?>><?= e($nav['label']) ?></a><?php endforeach; ?></nav>
<a class="button header-cta" href="<?= ready()?'/checkout':'/our-workbook' ?>">Get the workbook <span aria-hidden="true">↗</span></a><button class="menu-toggle" aria-expanded="false" aria-controls="mobile-menu" aria-label="Open navigation"><span></span><span></span></button>
</div><nav id="mobile-menu" class="mobile-menu" aria-label="Mobile navigation" hidden><?php foreach($navigation as $nav): if(empty($nav['visible']))continue; ?><a href="<?= e(safe_url($nav['url'],'/')) ?>"><?= e($nav['label']) ?><span aria-hidden="true">↗</span></a><?php endforeach; ?><a href="/our-workbook">Get the workbook</a></nav></header>
<?php if(isset($_SESSION['flash'])): $notice=$_SESSION['flash'];unset($_SESSION['flash']); ?><div class="notice <?= e($notice['type']) ?>" role="status"><?= e($notice['text']) ?></div><?php endif; ?>
<main id="main">
